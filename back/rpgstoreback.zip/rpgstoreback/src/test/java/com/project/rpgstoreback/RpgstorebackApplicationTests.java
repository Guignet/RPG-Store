package com.project.rpgstoreback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpgstorebackApplicationTests {

	@Test
	void contextLoads() {
	}

}
