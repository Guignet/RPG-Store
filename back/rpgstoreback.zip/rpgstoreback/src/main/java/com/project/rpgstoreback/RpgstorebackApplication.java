package com.project.rpgstoreback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpgstorebackApplication {

	public static void main(String[] args) {
		SpringApplication.run(RpgstorebackApplication.class, args);
	}

}
